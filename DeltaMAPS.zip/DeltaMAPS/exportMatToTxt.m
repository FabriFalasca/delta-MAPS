function exportMatToTxt( data,outFileName )
%%example script that exports a .mat file to text. The text file can be
%%used as an input to delta-MAPS as well.
%INPUT:
%%data : the matlab file that we need to export (file needs to be loaded
%%already in Matlab).
%%outFileName: String holding the name of the desired file name for the
%%.txt file. 

dimX = size(data,1);
dimY = size(data,2);
dimT = size(data,3);
maskVal = -1000000;%%default mask value. 

dimensions = [dimX,dimY,dimT];
dlmwrite(outFileName,dimensions,'-append');
for i = 1:dimX
    for j = 1:dimY
        ts = data(i,j,:); ts = ts(:);
        if(ts(1) ~= maskVal)
            tsWithLoc = [i,j,ts'];
            dlmwrite(outFileName,tsWithLoc,'-append');
        end;
    end;
end;


end

