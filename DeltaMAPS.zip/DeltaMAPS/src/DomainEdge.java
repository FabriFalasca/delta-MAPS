

public class DomainEdge {
    
    int from, to; //ids of the areas that take part on the edge.
    double weight; //edge weight.
    double sij; //correlation associated with the edge.
    
    //double minLag, maxLag;
    double lag; 
    boolean undirected = false;
    double[] correlogram;
    double[] sigcorrs;
    double[] bvar;
    int minLag,maxLag;
    
    public DomainEdge()
    {}
    
    public DomainEdge(int from, int to, double weight)
    {
        this.from = from;
        this.to = to;
        this.weight = weight;
    }
    
    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + this.from;
        hash = 11 * hash + this.to;
        return hash;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(this.getClass() != o.getClass())
            return false;
        DomainEdge e = (DomainEdge)o;
        return this.from == e.from && this.to == e.to;
    }
}
