

import com.jmatio.io.MatFileReader;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLDouble;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

/**
 *
 * @author Foudalis
 */


public class NetworkInference {
    
    Vector<Domain> domains;
    double[] latitudes;
    double[][][] dataArray;
    boolean[][] maskArray;
    int dimX,dimY,dimT;
    int maxLag;
    double fdrQ;//false discovery rate q.
    double alpha;//as an alternative to FDR one can use a simple t-test to determine significant correlations, alpha here is the significance level.
    PublicFunctions pf = new PublicFunctions();    
    String folderOut;
    
    /*
    Class constructor when the user wants to run network inference only. This constructor imports the .dmn file (holding
    the information about the identified domains) and at a second step calls the original network inference constructor.
    */
    public NetworkInference(DeltaMAPSclm parent, String  domainFile, File file, String latitudeFile, String testType)
    {
        //import the .dmn file.
        Vector<Domain> domains = new Vector<Domain>();
        try
        {
            BufferedReader in = new BufferedReader(new FileReader(domainFile));
            String line = in.readLine();
            try
            {
                while(line != null)
                {
                    //read domain id x,y centroid coordinates and color
                    String args[] = line.split(" ");
                    Domain domain = new Domain(Integer.parseInt(args[0]));
                    domain.centroid = new int[2];
                    domain.centroid[0] = Integer.parseInt(args[1]);
                    domain.centroid[1] = Integer.parseInt(args[2]);
                    domain.color = Double.parseDouble(args[3]);
                    domain.initGridCells();
                    //parse the grid cells in the domain.
                    line = in.readLine();
                    args = line.split(" ");
                    for(int i = 0; i < args.length; i++)
                        domain.gridCells.add(Integer.parseInt(args[i]));
                    //add the domain
                    domains.add(domain);
                    //go to the next domain
                    line = in.readLine();
                }
            }
            catch(NullPointerException npe)
            {}
            in.close();
        }
        catch(IOException ioe)
        {
            System.out.println("Could not parse .dmn file");
            System.out.println(ioe.getMessage());
            System.exit(4);
        }
        //call the original class constructor.
        NetworkInference ni = new NetworkInference(parent, domains, file, latitudeFile, testType);
                
    }
    /*
    "Original" class constructor when the user wants to run both domain identification and network inference.
    */
    public NetworkInference(DeltaMAPSclm parent, Vector<Domain> domains, File file, String latitudeFile, String testType)
    {        
        this.domains = domains;
        this.maxLag =  parent.maxLag;
        this.folderOut = parent.folderOut;
        if(testType.equalsIgnoreCase("true"))        
            this.fdrQ = parent.fdrQ;
        else
            this.alpha = parent.fdrQ;
        this.maskArray = parent.maskArray;
        System.out.println("Network inference starts...");
        //Step 1. load the mat file again (now we load the "full" time series so we can compute lags as well..
        System.out.println("Loading .mat file again.");
        String fname = file.getName();
        String args[] = fname.split("\\.");
        if(args[1].equalsIgnoreCase("mat"))
            loadFileMatlab(file);
        else
            loadFileTxt(file);
            
            
            
        //Step 2. Load the latitudes.
        loadLatitides(latitudeFile);
        System.out.println("Weighting time series in respect to grid cell size");
        resizeTimeSeries();
        setDomainSize();
        System.out.println("Constructing domain cummulative anomaly time series.");
        constructDomainCA();
        System.out.println("Constructing network");
        if(testType.equalsIgnoreCase("false"))//then run net inference using a t-test                    
            networkInferenceTtest();        
        else
        {//net inference using FDR.            
            double minPval = fdr();
            networkInferenceFDR(minPval);
        }
        
        setStrength();
        //construct two folders, one to output each area separately and one to output
        //the link maps of all areas.        
        File areaDirF = new File(this.folderOut.concat("domains"));
        areaDirF.mkdir();
        String areaFolder = areaDirF.getAbsolutePath().concat("/");
        File linkMapDirF = new File(this.folderOut.concat("linkMaps"));
        linkMapDirF.mkdir();
        String linkMapFolder = linkMapDirF.getAbsolutePath().concat("/");
        //export link maps and areas
        for(int x = 0; x < domains.size(); x++)
        {
            exportLinkMap(domains.get(x), Integer.toString(domains.get(x).id),linkMapFolder);
            exportLagInfo(domains.get(x), Integer.toString(domains.get(x).id),linkMapFolder);
            printDomain(domains.get(x),Integer.toString(domains.get(x).id),areaFolder);
        }
                
        exportDomainIDAndCentroid();
        
        
        mapColoring(domains);
        printDomainMap();
        
        
        //finally sort the areas by size.
        ComparatorDomainSize mycomp = new ComparatorDomainSize();
        java.util.Collections.sort(domains,mycomp);
        //get the largest area (which is typically ENSO).
        Domain enso = domains.firstElement();        
        //print a map of the area (to make sure that it is ENSO)
        printDomain(enso,"enso",folderOut);
        //print the strength and size of the area
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folderOut+"ensoStats.txt",true));//set true to append
            out.println(enso.gridCells.size()+"\t"+enso.size+"\t"+enso.strength);
            out.close();
        }
        catch(IOException ioe)
        {}

        printStrengthMap();
        exportNetwork();

    }
    
    private void setStrength()
    {
        HashSet<DomainEdge> edges = new HashSet<DomainEdge>();
        for(int i = 0; i < domains.size(); i++)
            edges.addAll(domains.get(i).edges);
        for(int i = 0; i < domains.size(); i++)
        {
            Domain domain = domains.get(i);
            double strength = 0.0;
            java.util.Iterator<DomainEdge> it = edges.iterator();
            while(it.hasNext())
            {
                DomainEdge e = it.next();
                if(e.undirected)
                {
                    if(e.from == domain.id)
                        strength+=Math.abs(e.weight);
                }
                else
                {
                    if(e.from == domain.id)
                        strength+=Math.abs(e.weight);
                    else if(e.to == domain.id)
                        strength+=Math.abs(e.weight);
                }
            }
            domains.get(i).strength = strength;
        }

    }
    
    private void networkInferenceTtest()
    {
        int nDomains = domains.size();
        int nEdgesTotal = 0, nEdgesDirected = 0;
        for(int i = 0; i < nDomains; i++) //search for an edge between all pairs of areas.
        {
            Domain d1 = domains.get(i);
            for(int j = (i+1); j < nDomains; j++)
            {
                Domain d2 = domains.get(j);                
                //step one is to get the correlogram
                double[] correlogram = getCorrelogram(d1.domainCA,d2.domainCA);
                //this array will keep the variance estimated by Bartlett.
                double[] bvar = new double[correlogram.length];
                //step two is to identify significant correlations, use the barlett formula
                double[] significantCorrelations = new double[correlogram.length];
                //(1) get the central part of the time series
                double ts1[] = new double[d1.domainCA.length-2*maxLag];
                double ts2[] = new double[d2.domainCA.length-2*maxLag];
    
                for(int x = maxLag; x < maxLag+ts1.length; x++)
                {
                    ts1[x-maxLag] = d1.domainCA[x];
                    ts2[x-maxLag] = d2.domainCA[x];
                }
                //estimate the variance according to Bartlett
                int T = ts1.length;
                double[] autocorrTS1 = new double[2*T+1];
                double[] autocorrTS2 = new double[2*T+1];
                for(int x = 0; x < T; x++)
                {
                    autocorrTS1[T+x] = autocorr(ts1, x);
                    autocorrTS2[T+x] = autocorr(ts2, x);
                    autocorrTS1[T-x] = autocorrTS1[T+x];
                    autocorrTS2[T-x] = autocorrTS2[T+x];
                }
                double var = 0; //after this point var is NOT normalized by T - \tau. 
                for(int x = 0; x < autocorrTS1.length; x++)
                    var+=autocorrTS1[x]*autocorrTS2[x];
                //and now find the significant correlations
                for(int x = 0; x < correlogram.length; x++)
                {
                    int currentLag = Math.abs(maxLag-x);
                    double corr = Math.abs(correlogram[x]); //by taking the absolute corr value is like doing a two-tailed t-test                    
                    //normalize with Bartlett variance
                    corr = corr/Math.sqrt(var/(T-currentLag)); //note: here we further normalize by T-\tau.
                    bvar[x] = Math.sqrt(var/(T-currentLag));
                    double pval = 1-DistLib.normal.cumulative(corr, 0.0, 1.0);                
                    if(pval < this.alpha)
                        significantCorrelations[x] = correlogram[x];//passed the test                                        
                }
                //finally get the edge.                
                DomainEdge e = edgeInfernce(significantCorrelations, bvar);
               
                if(e!=null)
                {   
                   
                    e.correlogram = new double[correlogram.length];
                    e.correlogram = correlogram;
                    e.bvar = bvar;
                    
                    nEdgesTotal++;
                    //then we have an edge, we need to get the direction and set the weight.
                    double alphaSTD = Math.sqrt(getVariance(ts1, getMean(ts1)));
                    double betaSTD = Math.sqrt(getVariance(ts2, getMean(ts2)));
                    e.weight = alphaSTD*betaSTD*e.sij;
   
                    if(e.minLag > 0 ) ///all lags are positive d1 -> d2
                    {
                        e.from = d1.id;
                        e.to = d2.id;
                        domains.get(i).edges.add(e);
                        nEdgesDirected++;
                    }
                    else if(e.maxLag < 0) //all lagsnegative lag d2 -> d1
                    {
                        e.from = d2.id;
                        e.to = d1.id;
                        domains.get(j).edges.add(e);
                        nEdgesDirected++;
                    }
                    else//undirected (lag range includes 0)
                    {
                        DomainEdge e2 = new DomainEdge();
                        e2.correlogram = new double[correlogram.length];
                        e2.correlogram = correlogram;
                        e2.sigcorrs = new double[correlogram.length];
                        e2.sigcorrs = e.sigcorrs;
                        e2.bvar = e.bvar;
                        e2.sij = e.sij;
                        e2.lag = e.lag;
                        e2.maxLag = e.maxLag;
                        e2.minLag = e.minLag;
                        e2.weight = e.weight;
                        e.from = d1.id;
                        e.to = d2.id;
                        e.undirected=true;
                        domains.get(i).edges.add(e);
                        e2.from = d2.id;
                        e2.to = d1.id;
                        e2.undirected=true;
                        domains.get(j).edges.add(e2);
                    }
                }
            }
        }
        System.out.println("#Edges (total): "+nEdgesTotal);
        System.out.println("#Edges (directed): "+nEdgesDirected);             
    }

    
    private void networkInferenceFDR(double minPval)
    {
        int nDomains = domains.size();
        int nEdgesTotal = 0, nEdgesDirected = 0;
        for(int i = 0; i < nDomains; i++) //search for an edge between all pairs of areas.
        {
            Domain d1 = domains.get(i);
            for(int j = (i+1); j < nDomains; j++)
            {
                Domain d2 = domains.get(j);                
                //step one is to get the correlogram
                double[] correlogram = getCorrelogram(d1.domainCA, d2.domainCA);
                //this array will keep the variance estimated by Bartlett.
                double[] bvar = new double[correlogram.length];
                //step two is to identify significant correlations, use the barlett formula
                double[] significantCorrelations = new double[correlogram.length];
                //(1) get the central part of the time series
                double ts1[] = new double[d1.domainCA.length-2*maxLag];
                double ts2[] = new double[d2.domainCA.length-2*maxLag];
    
                for(int x = maxLag; x < maxLag+ts1.length; x++)
                {
                    ts1[x-maxLag] = d1.domainCA[x];
                    ts2[x-maxLag] = d2.domainCA[x];
                }
                //estimate the variance according to Bartlett
                int T = ts1.length;
                double[] autocorrTS1 = new double[2*T+1];
                double[] autocorrTS2 = new double[2*T+1];
                for(int x = 0; x < T; x++)
                {
                    autocorrTS1[T+x] = autocorr(ts1, x);
                    autocorrTS2[T+x] = autocorr(ts2, x);
                    autocorrTS1[T-x] = autocorrTS1[T+x];
                    autocorrTS2[T-x] = autocorrTS2[T+x];
                }
                double var = 0; //after this point var is NOT normalized by T - \tau. 
                for(int x = 0; x < autocorrTS1.length; x++)
                    var+=autocorrTS1[x]*autocorrTS2[x];
                //and now find the significant correlations
                for(int x = 0; x < correlogram.length; x++)
                {
                    int currentLag = Math.abs(maxLag-x);
                    double corr = Math.abs(correlogram[x]); //by taking the absolute corr value is like doing a two-tailed t-test                    
                    //normalize with Bartlett variance
                    corr = corr/Math.sqrt(var/(T-currentLag)); //note: here we further normalize by T-\tau.
                    bvar[x] = Math.sqrt(var/(T-currentLag));
                    double pval = 1-DistLib.normal.cumulative(corr, 0.0, 1.0);                
                    if(pval <= minPval)
                        significantCorrelations[x] = correlogram[x];//passed the test                                        
                }
                //finally get the edge.
                DomainEdge e = edgeInfernce(significantCorrelations, bvar);
                if(e!=null)
                {   
                   
                    e.correlogram = new double[correlogram.length];
                    e.correlogram = correlogram;
                    e.bvar = bvar;
                    nEdgesTotal++;
                    //then we have an edge, we need to get the direction and set the weight.
                    double alphaSTD = Math.sqrt(getVariance(ts1, getMean(ts1)));
                    double betaSTD = Math.sqrt(getVariance(ts2, getMean(ts2)));
                    e.weight = alphaSTD*betaSTD*e.sij;
   
                    if(e.minLag > 0 ) ///all lags are positive d1 -> d2
                    {
                        e.from = d1.id;
                        e.to = d2.id;
                        domains.get(i).edges.add(e);
                        nEdgesDirected++;
                    }
                    else if(e.maxLag < 0) //all lags are negative lag d2 -> d1
                    {
                        e.from = d2.id;
                        e.to = d1.id;
                        domains.get(j).edges.add(e);
                        nEdgesDirected++;
                    }
                    else//undirected (lag range includes 0)
                    {
                        DomainEdge e2 = new DomainEdge();
                        e2.correlogram = new double[correlogram.length];
                        e2.correlogram = correlogram;
                        e2.sigcorrs = new double[correlogram.length];
                        e2.sigcorrs = e.sigcorrs;
                        e2.bvar = e.bvar;
                        e2.sij = e.sij;
                        e2.lag = e.lag;
                        e2.maxLag = e.maxLag;
                        e2.minLag = e.minLag;
                        e2.weight = e.weight;
                        e.from = d1.id;
                        e.to = d2.id;
                        e.undirected=true;
                        domains.get(i).edges.add(e);
                        e2.from = d2.id;
                        e2.to = d1.id;
                        e2.undirected=true;
                        domains.get(j).edges.add(e2);
                    }
                }
            }
        }
        System.out.println("#Edges (total): "+nEdgesTotal);
        System.out.println("#Edges (directed): "+nEdgesDirected);
    }
    
    /*
    INPUT: significantCorrelations: 2\times maxLag+1 array holding the significant correlations (if a correlation is not significant then it is set to 0)
    bVar: 2 \times maxLag +1 array holding the standard deviation of a correlation at lag \tau
    This function infers and edge given a correlogram and the standard deviation of each correlation estimated by Bartlett
    If no correlations are found significant then no edge exists, the function returns NULL
    If at least one correlation is significant then the function returns an edge, the correlation corresponding to the edge
    and the lag or lag range corresponding to the edge.
    */
    private DomainEdge edgeInfernce(double[] significantCorrelations, double[] bartlettVar)
    {
        //Step 1. Find the maximal significant correlation in absolute sense and the lag associated with it.
        double maxCorr  = 0;
        int lag = 0;
        for(int i = 0; i < significantCorrelations.length; i++)
            if(Math.abs(maxCorr) < Math.abs(significantCorrelations[i]))
            {
                maxCorr = significantCorrelations[i];
                lag = i;
            }
        if(maxCorr == 0)
        {
            return null;// no edge
        }
        else
        {   // an edge exists
            DomainEdge e = new DomainEdge();
            e.sij = maxCorr;//max correlation in absolute sense
            e.lag = lag-this.maxLag;//lag corresponding to max correlation in absolute sense
            e.sigcorrs = new double[significantCorrelations.length];
            e.sigcorrs = significantCorrelations;
            //now get the Bartlett variance at maxCorr
            double maxBvar = bartlettVar[lag];
            //scan through the significant correlations
            int[] lagRange = new int[bartlettVar.length];
            for(int i = 0; i < significantCorrelations.length; i++)
            {   //and here we return the lag, or lag range associated with the edge.
                double corr = Math.abs(significantCorrelations[i]);
                if(corr > 0)
                {
                    double cVar = bartlettVar[i];
                    if(corr >= Math.abs(maxCorr))
                    {
                        if(Math.abs(maxCorr)+maxBvar > corr-cVar)
                            lagRange[i] = 1;
                    }
                    else
                    {
                    if(Math.abs(maxCorr)-maxBvar < corr+cVar)
                        lagRange[i] = 1;
                    }
                }
            }
            int minLag = 0, maxLag = 0;
            for(int i = 0; i < lagRange.length; i++)
                if(lagRange[i] > 0)
                {
                    minLag = i;
                    break;
                }
            for(int i = lagRange.length-1; i >= 0; i--)
                if(lagRange[i] > 0)
                {
                    maxLag = i;
                    break;
                }
            e.maxLag = maxLag-this.maxLag;
            e.minLag = minLag-this.maxLag;
            return e;
        }
    }
        
    

    
    private double fdr()
    {
        System.out.println("Starting FDR, q set to "+this.fdrQ);
        Vector<Double> pvalues = new Vector<Double>();
        int nDomains = domains.size();
        for(int i = 0; i < nDomains; i++)
        {
            Domain d1 = domains.get(i);
            for(int j = (i+1); j < nDomains; j++)
            {
                Domain d2 = domains.get(j);
                //calculate the correlations between the two domains over the lag range.
                double[] correlogram = getCorrelogram(d1.domainCA,d2.domainCA);              
                //get the central part of the time series
                double ts1[] = new double[d1.domainCA.length-2*maxLag];
                double ts2[] = new double[d2.domainCA.length-2*maxLag];    
                for(int x = maxLag; x < maxLag+ts1.length; x++)
                {
                    ts1[x-maxLag] = d1.domainCA[x];
                    ts2[x-maxLag] = d2.domainCA[x];
                }
                //estimate the variance according to Bartlett
                int T = ts1.length;
                //calculate the autocorrelation 
                double[] autocorrTS1 = new double[2*T+1];
                double[] autocorrTS2 = new double[2*T+1];
                for(int x = 0; x < T; x++)
                {
                    autocorrTS1[T+x] = autocorr(ts1, x);
                    autocorrTS2[T+x] = autocorr(ts2, x);
                    //autocorrelation is symemtric....
                    autocorrTS1[T-x] = autocorrTS1[T+x];
                    autocorrTS2[T-x] = autocorrTS2[T+x];
                }
                //estimate the variance
                double var = 0; //after this point var is NOT normalized by T - \tau. 
                for(int x = 0; x < autocorrTS1.length; x++)
                    var+=autocorrTS1[x]*autocorrTS2[x];
                //and now find the significant correlations
                for(int x = 0; x < correlogram.length; x++)
                {
                    int currentLag = Math.abs(maxLag-x);
                    double corr = Math.abs(correlogram[x]); //by taking the absolute corr value is like doing a two-tailed t-test                    
                    //normalize with Bartlett variance
                    corr = corr/Math.sqrt(var/(T-currentLag)); //note: here we further normalize by T-\tau.
                    double pval = 1-DistLib.normal.cumulative(corr, 0.0, 1.0);                
                    pvalues.add(pval);
                }
            }
        }
        //sort the p-values.
        java.util.Collections.sort(pvalues);
        System.out.println("First pval: "+pvalues.firstElement());
        System.out.println("Last pval: "+pvalues.lastElement());
        double M = pvalues.size();
        double k = 1;
        double minPval = 0;
        for(int i = 0; i < pvalues.size(); i++)
        {
            double pval = pvalues.get(i);
            double fdrRatio = 0;            
            fdrRatio = (this.fdrQ*k)/M;
            
            if(pval > fdrRatio)
            {
                try
                {
                    minPval = pvalues.get(i-1);
                    break;
                }
                catch(ArrayIndexOutOfBoundsException aio)
                {minPval = 0.0;}
            }
            k++;
        }
        System.out.println("FDR stops, min pvalue "+minPval);
        return minPval;
    }

    
    /*
    returns the autocorrelation of ts at the specified lag
    */
    private double autocorr(double[] tsFoo, int lag)
    {
        double[] ts = Arrays.copyOf(tsFoo, tsFoo.length);
        double mean = getMean(ts);
        double var = getVariance(ts, mean);
        double auto = 0.0;
        for(int i = 0; i < (ts.length-lag); i++)        
            auto+= (ts[i]-mean)*(ts[i+lag]-mean);
        auto = auto/( ((double)ts.length)*var );
        return auto;
    }

    private double[] getCorrelogram(double[] ts1Foo, double[] ts2Foo)
    {                        
        double[] ts1 = Arrays.copyOf(ts1Foo, ts1Foo.length);
        double[] ts2 = Arrays.copyOf(ts2Foo, ts2Foo.length);
        double cijtauArray[] = new double[2*this.maxLag+1];        
     
        //corelation at lag zero
        cijtauArray[this.maxLag]  = pearsonCorrel(ts1, ts2, maxLag,0);        
                
        //start by shifting the second time series to the right
        for(int i = 1; i <= this.maxLag; i++)                
            cijtauArray[this.maxLag+i] = pearsonCorrel(ts1, ts2,maxLag,i);            
        //continue by shifting the time serises to the left
        for(int i = -1; i >= -this.maxLag; i--)                    
            cijtauArray[this.maxLag+i] =  pearsonCorrel(ts1, ts2,maxLag,i);                    
        return cijtauArray;
    }
    
    private double pearsonCorrel(double[] scores1, double[] scores2, int startPos, int lag)
    {    
        double correl = 0.0;
    
        double[] ts1 = new double[scores1.length-2*startPos];
        double[] ts2 = new double[scores1.length-2*startPos];
        
        //get the part of the time series that you want
        for(int i = startPos; i < startPos+ts1.length; i++)
        {
            ts1[i-startPos] = scores1[i];
            ts2[i-startPos] = scores2[i+lag];
        }
        
        //set to unit variance, zero mean first
        ts1 = normalizeToZeroMeanUnitVar(ts1);
        ts2 = normalizeToZeroMeanUnitVar(ts2);
        for(int i = 0; i < ts1.length; i++)
            correl+=ts1[i]*ts2[i];
        
        return correl/(double)ts1.length;        
    }     

    
    private double[] normalizeToZeroMeanUnitVar(double[] ts)
    {
        double mean = getMean(ts);
        double std = Math.sqrt(getVariance(ts, mean));
        for(int i = 0; i < ts.length; i++)
            ts[i] = (ts[i]-mean)/std;
        return ts;
    }
    
    private double getVariance(double[] ts, double mean)
    {
        double var = 0.0;
        for(int i = 0; i < ts.length; i++)        
            var += Math.pow(ts[i]-mean, 2);
        var/=(double)(ts.length-1);
        return var;
    }

    private double getMean(double[] ts)
    {
        double mean = 0.0;
        for(int i = 0; i < ts.length; i++)
            mean+=ts[i];
        mean/=(double)(ts.length);
        return mean;
    }

    

    private void constructDomainCA()
    {
        for(int i = 0; i < domains.size(); i++)            
        {
            Domain domain = domains.get(i);
            double domainCA[] = new double[dimT];
            Iterator<Integer> it = domain.gridCells.iterator();
            while(it.hasNext())
            {
                int pos[] = pf.getPosition(it.next(), dimX, dimY);
                double[] ts = dataArray[pos[0]][pos[1]];
                for(int t = 0; t < ts.length; t++)
                    domainCA[t] = domainCA[t]+ts[t];
            }            
            domains.get(i).initDomainCA(domainCA);
        }
    }

    
    private void setDomainSize()
    {
        Domain domain;
        for(int i = 0; i < domains.size(); i++)
        {
            domain = domains.get(i);
            double size = 0.0;
            Iterator<Integer> it = domain.gridCells.iterator();
            while(it.hasNext())
            {
                int pos[] = pf.getPosition(it.next(), dimX, dimY);
                //get the latitude of the grid cell and get the size
                double degreeLat = latitudes[pos[0]];
                size+= Math.abs(Math.cos(Math.toRadians(degreeLat)));
            }
            domains.get(i).size = size;                            
        }        
    }

    
        //resizes each value of the time series by the real size of the grid cell (cos(pji_i)).
    private void resizeTimeSeries()
    {
        for(int i = 0; i < dimY; i++)
        {
            for(int j = 0; j < dimX; j++)
            {
                double lat = latitudes[j];
                double weight = Math.abs(Math.cos(Math.toRadians(lat)));
                for(int z = 0; z < dimT; z++)
                    dataArray[j][i][z] = dataArray[j][i][z]*weight;
            }
        }
    }

    /*
    latitudeFile: Path to the file holding the latitudes of the current data set analysed.
    The latitude file should be formated as follows:
    (1) Latitudes have to be comma separated values.
    (2) Latitudes should start from -90 to 90.
    Example -89,-88,-87 ... ... 87,88,89
    */
    private void loadLatitides(String latitudeFile)
    {
        try
        {
            this.latitudes = new double[dimY];
            BufferedReader in = new BufferedReader(new FileReader(latitudeFile));
            String line = in.readLine();
            String args[] = line.split(",");
            if(args.length != dimX)
                System.out.println("Warning: Latitudes in file do not match data set dimensions.");
            for(int i = 0; i < args.length; i++)
            {
                try
                {
                    latitudes[i] = Double.parseDouble(args[i]);
                }
                catch(ArrayIndexOutOfBoundsException aio)
                {                    
                }
            }
            in.close();
            
            
        }
        catch(IOException ioe)
        {
            System.out.println("Could not open latitude file.");
            System.out.println(ioe.getMessage());
            System.exit(2);
        }
    }
    
    
    
    private void loadFileMatlab(File filename)
    {        
        try
        {
            MatFileReader mat = new MatFileReader(filename);
            HashMap<String,MLArray> contents = new HashMap<String,MLArray>();
            contents = (HashMap)mat.getContent();//get all the arrays of the mat file.
            //get their names.
            Set keys = contents.keySet();
            Object[] keynames = keys.toArray();
            //Now I just want the first array.
            
            MLDouble mldouble = (MLDouble)(contents.get(keynames[0].toString()));
            double [][] temp = mldouble.getArray();
            
            int[] dimIds = mldouble.getDimensions();
            dimX = dimIds[0]; dimY = dimIds[1]; dimT = dimIds[2];
            //reshape temp
            dataArray = new double[dimX][dimY][dimT];
            
            for(int i = 0; i < dimX; i++)
            {
                int timePos = 0, lonPos = 0;;
                for(int j = 0; j < temp[i].length; j++)
                {
                    dataArray[i][lonPos][timePos] = temp[i][j];
                    lonPos++;
                    if(lonPos%(dimY)==0) //-1 cause have counts from 0.
                    {
                        lonPos = 0;
                        timePos = timePos+1;
                    }
                }
            }
            temp = null;
            System.gc();
        }
        catch(IOException io)
        {
            System.out.println("Error parsing .mat file.");
        }
    }
    
    private void loadFileTxt(File filename)
    {
                
        try
        {
            BufferedReader in = new BufferedReader(new FileReader(filename));
            //Step 1. Get the dimensions.
            String line = in.readLine();
            String[] args = line.split(",");
            this.dimX = Integer.parseInt(args[0]);
            this.dimY = Integer.parseInt(args[1]);
            this.dimT = Integer.parseInt(args[2]);
    
            //Step 2. Initialize the data structures
            dataArray = new double[dimX][dimY][dimT];
            maskArray = new boolean[dimX][dimY];
            for(int i = 0; i < dimX; i++)
                for(int j = 0; j < dimY; j++)
                    maskArray[i][j]=true;
            //Step 3. Load the time series.
            line = in.readLine();
            try
            {
                while(true)
                {                    
                    args = line.split(",");
                    //get the position of the time series in the grid.
                    int posX = Integer.parseInt(args[0]);
                    int posY = Integer.parseInt(args[1]);
                    //get the time series
                    int cc = 0;
                    for(int i = 2; i < args.length; i++)
                    {
                        dataArray[posX-1][posY-1][cc] = Double.parseDouble(args[i]);
                        cc++;
                    }
                    maskArray[posX-1][posY-1] = false;
                    line = in.readLine();
                }
            }
            catch(NullPointerException npe)
            {}
            
            in.close();
        }
        catch(IOException ioe)
        {
            System.out.println("Could not load file: "+filename.getName());
            System.out.println(ioe.getMessage());
            System.exit(2);
        }
    }

    
    /*
    EXPORT FUNCTIONS GO HERE
    */
    
    private void exportLinkMap(Domain from,String delimiter,String folder)
    {
        String linkMap[][] = new String[dimX][dimY];
        for(int i = 0; i < dimX; i++)
            for(int j = 0; j < dimY; j++)
                linkMap[i][j]=Double.toString(0.0);
        //out links
        for(int i = 0; i < from.edges.size(); i++)
        {
            DomainEdge e = from.edges.get(i);
            Domain domainTo = new Domain(e.to);
            domainTo = domains.get((domains.indexOf(domainTo)));
            Iterator<Integer> it = domainTo.gridCells.iterator();
            while(it.hasNext())
            {
                int pos[] = pf.getPosition(it.next(), dimX, dimY);
                linkMap[pos[0]][pos[1]] = Double.toString(e.weight);
            }
        }
        //in links
        for(int x = 0; x < domains.size(); x++)
        {
            Domain domain = domains.get(x);
            for(int i = 0; i < domain.edges.size(); i++)
            {
                DomainEdge e = domain.edges.get(i);
                if(e.to == from.id)
                {
                    Iterator<Integer> it = domain.gridCells.iterator();
                    while(it.hasNext())
                    {
                        int pos[] = pf.getPosition(it.next(), dimX, dimY);
                        linkMap[pos[0]][pos[1]] = Double.toString(e.weight);
                    }                   
                }
            }
        }
        Iterator<Integer> it = from.gridCells.iterator();
        while(it.hasNext())
        {
            int pos[] = pf.getPosition(it.next(), dimX, dimY);
            linkMap[pos[0]][pos[1]] = "NaN";
        }
        
        
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folder+"linkMap_"+from.id+"_"+delimiter+".txt"));
            
            for(int i = 0; i < dimX; i++)
            {
                for(int j = 0; j < dimY; j++)
                    out.print(linkMap[i][j]+" ");
                out.println();
            }
            out.close();
            
            
        }
        catch(IOException ioe)
        {}

    }
    
    private void exportDomainIDAndCentroid()
    {
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folderOut+"domainIDandCentroid.txt"));
            for(int i = 0; i < domains.size(); i++)
            {
                Domain alpha = domains.get(i);
                out.println(alpha.id+"\t"+alpha.centroid[0]+"\t"+alpha.centroid[1]);
            }
            out.close();
        }
        catch(IOException ioe)
        {}
    }

    private void exportLagInfo(Domain from, String delimiter,String folder)
    {        
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folder+"domainCentroidAndLag_"+delimiter+".txt"));
            HashSet<DomainEdge> edges = new HashSet<DomainEdge>();
            for(int i = 0; i < domains.size(); i++)
                edges.addAll(domains.get(i).edges);
            Iterator<DomainEdge> it = edges.iterator();
            while(it.hasNext())
            {
                DomainEdge e = it.next();
                Domain domain = null;
                int lagSign = 0;
                if(e.to == from.id)//then this area points to you
                {
                    domain = new Domain(e.from);
                    domain = domains.get(domains.indexOf(domain));
                    lagSign = -1;
                }
                else if(e.from == from.id)//then you point to an area
                {
                    domain = new Domain(e.to);
                    domain = domains.get(domains.indexOf(domain));
                    lagSign = 1;
                }
                if(domain!=null)    
                    out.println(domain.centroid[0]+" "+domain.centroid[1]+" "+(lagSign*Math.abs(e.lag)));
                
                
            }
            out.close();
        }
        catch(IOException ioe)
        {}                
    }
    
    private void mapColoring(Vector<Domain> domains)
    {
        Hashtable colorgraph[] = new Hashtable[domains.size()];
        Hashtable<Integer,Integer> mapIdCurrentToNew = new Hashtable<Integer,Integer>();
        Hashtable<Integer,Integer> mapIdNewToCurrent = new Hashtable<Integer,Integer>();
        for(int i = 0; i <  domains.size(); i++)
        {
            Domain alpha = domains.get(i);
            mapIdCurrentToNew.put(alpha.id, i);
            mapIdNewToCurrent.put(i, alpha.id);
        }
        for(int i = 0; i < colorgraph.length; i++)
            colorgraph[i] = new Hashtable<Integer,Integer>();
        //transform the map to a graph
        //a link will connect to areas in the map if they are adjacent
        for(int i = 0; i < domains.size(); i++)
        {
            Domain alpha = domains.get(i);
            ArrayList<Integer> neighbors = findNeighborsMapColoring(domains,alpha);
            Integer from = mapIdCurrentToNew.get(alpha.id);
            for(int j = 0; j < neighbors.size(); j++)
            {
                Integer to = mapIdCurrentToNew.get(neighbors.get(j));
                colorgraph[from].put(to, to);
            }            
        }
        //I need it also as a Vector of areas...
        ArrayList<Domain> domainsMap = new ArrayList<Domain>();
        for(int i = 0; i < colorgraph.length; i++ )
        {
            Domain alpha = new Domain(i);
            alpha.mapColEdges = new ArrayList<>();
            java.util.Enumeration<Integer> neighs = colorgraph[i].keys();
            while(neighs.hasMoreElements())
            {
                Integer neigh = neighs.nextElement();
                alpha.mapColEdges.add(new Edge(i, neigh));
            }
            domainsMap.add(alpha);
        }
        ArrayList<Domain> removeOrder = new ArrayList<Domain>();
        DomainDegreeComparator degreeComp = new DomainDegreeComparator();
        while(!domainsMap.isEmpty())
        {
            //sort the areas by degree in ascending order
            java.util.Collections.sort(domainsMap,degreeComp);
            //remove the area with the lowest degree
            Domain alpha = domainsMap.remove(0);
            //remove all edges from alpha to other areas...
            for(int i = 0; i < alpha.edges.size(); i++)
            {
                Edge e = alpha.mapColEdges.get(i);
                for(int j = 0; j < domainsMap.size(); j++)
                    if(domainsMap.get(j).edges.contains(e))
                        domainsMap.get(j).edges.remove(e);
            }
            removeOrder.add(alpha);
        }
        //initialize again the vector of areas, we will use it to set their colors
        domainsMap = new ArrayList<>();
        for(int i = 0; i < colorgraph.length; i++ )
        {
            Domain alpha = new Domain(i);
            alpha.mapColEdges = new ArrayList<>();
            domainsMap.add(alpha);
            //no need to know the edges here.        
        }
        double colorArray[] = {0.2,0.4,0.6,0.8,1.0};
        //now start removing the nodes in the remove order "stack-wise"
        while(!removeOrder.isEmpty())
        {
            Domain alpha = removeOrder.remove(0);
            //and pick a color for alpha that is not used by its neighbors;
            boolean[] colorUsed = new boolean[5];
            for(int j = 0; j < colorUsed.length; j++)
                colorUsed[j] = false;
            java.util.Enumeration<Integer> neighs = colorgraph[alpha.id].keys();
            while(neighs.hasMoreElements())
            {
                Integer neigh = neighs.nextElement();
                Domain dummy = new Domain(neigh);
                dummy = domainsMap.get(domainsMap.indexOf(dummy));
                if(dummy.color > 0.0)
                {
                    if(dummy.color == 0.2)
                        colorUsed[0] = true;
                    else if(dummy.color == 0.4)
                        colorUsed[1] = true;
                    else if(dummy.color == 0.6)
                        colorUsed[2] = true;
                    else if(dummy.color == 0.8)
                        colorUsed[3] = true;
                    else colorUsed[4] = true;                                            
                }
            }
            //now scan the colorUsed array and pick a color for you...
            //one that is not used by your neighbors.
            //if you can't find such a color... problem             
            int colorid = -1;
            for(int j = 0; j < colorUsed.length; j++)
                if(!colorUsed[j])
                {
                    colorid = j;
               //     System.out.println(colorid);
                    break;
                }
            if(colorid == -1)
            {
                domainsMap.get(domainsMap.indexOf(alpha)).color = 1.2;
                System.out.println("Problem, no available colors.");
            }
            else
            {
                domainsMap.get(domainsMap.indexOf(alpha)).color = colorArray[colorid];
            }
                
        }
        //finally set the initial area colors
        for(int i = 0; i < domainsMap.size(); i++)
        {
            Domain alpha = domainsMap.get(i);                        
            Integer oldId = mapIdNewToCurrent.get(alpha.id);
            Domain dummy = new Domain(oldId);
            
            this.domains.get(this.domains.indexOf(dummy)).color = alpha.color;
            
        }
    }
    
    private ArrayList<Integer> findNeighborsMapColoring(Vector<Domain> domains,Domain alpha)
    {
        
        ArrayList<Integer> neighIds = new ArrayList<>();
        Iterator<Integer> it = alpha.gridCells.iterator();
        while(it.hasNext())
        {
            Vector<Integer> cellNeighs = pf.getNeighborsCross(it.next(), dimX, dimY);
            for(int j = 0; j < cellNeighs.size(); j++)
            {
                Integer cellID = new Integer(cellNeighs.get(j));
                if(!alpha.gridCells.contains(cellID))
                {                    
                    for(int x = 0; x < domains.size(); x++)
                    {
                        Domain beta = domains.get(x);
                        if(beta.gridCells.contains(cellID))
                        {                            
                            if(!neighIds.contains(beta.id))
                            {               
                                neighIds.add(new Integer(beta.id));
                            }
                        }
                    }
                }
            }    
        }
        
        return neighIds;
    }
    
    private void exportNetwork()
    {
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folderOut+"network.txt"));
            HashSet<DomainEdge> edges = new HashSet<DomainEdge>();
            for(int i = 0; i < domains.size(); i++)
                edges.addAll(domains.get(i).edges);
            Iterator<DomainEdge> it = edges.iterator();
            while(it.hasNext())
            {
                DomainEdge e = it.next();
                if(!e.undirected)
                    out.println(e.from+" "+e.to+" "+e.weight+" "+e.minLag+" "+e.maxLag+" "+e.sij);
                else
                {
                    if(e.from < e.to)
                        out.println(e.from+" "+e.to+" "+e.weight+" "+e.minLag+" "+e.maxLag+" "+e.sij);
                }
            }
            out.close();
        }
        catch(IOException ioe)
        {}
    }
    
    private void printDomainMap()
    {
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folderOut+"map_domains.txt"));
            double[][] map = new double[dimX][dimY];
            for(int i = 0; i < domains.size(); i++)
            {
                Domain alpha = domains.get(i);
                double color = alpha.color;
                Iterator<Integer> it = alpha.gridCells.iterator();
                while(it.hasNext())
                {
                    int pos[] = pf.getPosition(it.next(), dimX, dimY);
                    if(map[pos[0]][pos[1]] > 0)//overlap
                        map[pos[0]][pos[1]] = 1.4;
                    else
                         map[pos[0]][pos[1]] = color;
                }
            }
            for(int i = 0; i < dimX; i++)
            {
                for(int j = 0; j < dimY; j++)                
                    out.print(map[i][j]+" ");
                out.println();
            }
            out.close();
            
        }
        catch(IOException ioe)
        {}
    }
    
    private void printStrengthMap()
    {
        double[][] map = new double[dimX][dimY];
        for(int i = 0; i < domains.size(); i++)
        {
            Domain alpha = domains.get(i);
            double strength = alpha.strength;
            Iterator<Integer> it = alpha.gridCells.iterator();
            while(it.hasNext())
            {
                int pos[] = pf.getPosition(it.next(), dimX, dimY);
                if(strength > map[pos[0]][pos[1]] )
                    map[pos[0]][pos[1]] = strength;                
            }
        }
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folderOut+"strengthMap.txt"));
            for(int i = 0; i < dimX; i++)
            {
                for(int j = 0; j < dimY; j++)
                    out.print(map[i][j]+" ");
                out.println();
            }
            out.close();
        }
        catch(IOException ioe)
        {}
    }

    private void printDomain(Domain domain,String delimiter,String folder)
    {
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folder+"domain_"+delimiter+".txt"));
            double[][] map = new double[dimX][dimY];
            Iterator<Integer> it = domain.gridCells.iterator();
            while(it.hasNext())            
            {
                int[] pos = pf.getPosition(it.next(), dimX, dimY);
                map[pos[0]][pos[1]] = 1;
            }
            for(int i = 0; i < dimX; i++)
            {
                for(int j = 0; j < dimY; j++)
                    out.print(map[i][j]+" ");
                out.println();
            }
            out.close();
        }
        catch(IOException ioe)
        {}
    }




    
}


class DomainDegreeComparator implements Comparator<Domain>{
    @Override
    public int compare(Domain alpha, Domain beta)
    {
        if(alpha.edges.size() > beta.edges.size())
            return 1;
        else if(alpha.edges.size() < beta.edges.size())
            return -1;
        else return 0;
    }
}


class ComparatorDomainSize implements Comparator<Domain>
{
    public int compare(Domain alpha, Domain beta)
    {
        if(alpha.size > beta.size)
            return -1;
        else if(alpha.size < beta.size)
            return 1;
        else return 0;
    }
}
