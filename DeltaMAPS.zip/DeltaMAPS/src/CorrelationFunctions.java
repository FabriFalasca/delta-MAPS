

import java.util.Arrays;

/**
 *
 * @author Foudalis
 */
public class CorrelationFunctions {
    
    int dimT;
    public CorrelationFunctions(int dimT)
    {
        this.dimT = dimT;
    }
    
    /*
    function to estimate the variance according to Bartlett's formula.
    */
    public double varianceBartlett(double[] ts11, double[] ts21)
    {
        double[] ts1 = Arrays.copyOf(ts11, dimT);
        double[] ts2 = Arrays.copyOf(ts21, dimT);
        //autocorrelation from [-T,T] for ts1 and ts2
        double[] autocorrTS1 = new double[2*dimT+1];
        double[] autocorrTS2 = new double[2*dimT+1];
        for(int i = 0; i < dimT; i++)
        {
            autocorrTS1[dimT+i] = autocorr(ts1, i);
            autocorrTS2[dimT+i] = autocorr(ts2, i);
            autocorrTS1[dimT-i] = autocorrTS1[dimT+i];
            autocorrTS2[dimT-i] = autocorrTS2[dimT+i];
        }
        double var = 0.0;
        for(int i = 0; i < autocorrTS1.length; i++)
            var+= autocorrTS1[i]*autocorrTS2[i];
        return var/(double)dimT;        
    }
    
    /*
    returns the autocorrelation of the time series (ts) at a given lag.
    */
    public double autocorr(double[] ts, int lag)
    {        
        double mean = getMean(ts);
        double var = getVariance(ts, mean);
        double auto = 0.0;
        for(int i = 0; i < (dimT-lag); i++)        
            auto+= (ts[i]-mean)*(ts[i+lag]-mean);
        auto = auto/( ((double)dimT)*var );
        return auto;
    }
    

    /*
    reeturn the pearson correlation between time series ts1,ts2
    */
    public double pearsonCorrel(double[] ts1, double[] ts2)
    {
       double[] scores1 = Arrays.copyOf(ts1, dimT);
       double[] scores2 = Arrays.copyOf(ts2, dimT);
       scores1 = normalizeToZeroMeanUnitVar(scores1);
       scores2 = normalizeToZeroMeanUnitVar(scores2);
       double correl = 0.0;
       for(int i = 0; i < scores1.length; i++)
           correl+=scores1[i]*scores2[i];
       correl = correl/(double)dimT;
       
       return correl;
    }
    
    /*
    Same as the pearsonCorrel function but assumes that the input time series
    are already normalized to zero mean and unit variance
    */    
    public double pearsonCorrelNorm(double ts1[], double ts2[])
    {
        double[] scores1 = Arrays.copyOf(ts1, dimT);
        double[] scores2 = Arrays.copyOf(ts2, dimT);
        double correl = 0.0;
        for(int i = 0; i < ts1.length; i++)
           correl+=scores1[i]*scores2[i];
        correl = correl/(double)dimT;
       
        return correl;
    }
    
    
    /*
    normalizes a time series to zero mean and unit variance.
    */
    public double[] normalizeToZeroMeanUnitVar(double[] ts)
    {
        double mean = getMean(ts);
        double std = Math.sqrt(getVariance(ts, mean));
        for(int i = 0; i < ts.length; i++)
            ts[i] = (ts[i]-mean)/std;
        return ts;
    }
    
    /*
    return the mean of the time series.
    */
    public double getMean(double[] ts)
    {
        double mean = 0.0;
        for(int i = 0; i < ts.length; i++)
            mean+=ts[i];
        mean/=(double)(ts.length);
        return mean;
    }
       
    /*
    return the variance of the time series.
    */
    public double getVariance(double[] ts, double mean)
    {
        double var = 0.0;
        for(int i = 0; i < ts.length; i++)        
            var += Math.pow(ts[i]-mean, 2);
        var/=(double)(ts.length-1);
        return var;
    }

    
}
