

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

/**
 *
 * @author Foudalis
 */
public class DomainIdentification {
    
    double delta;
    double[][][] dataArray;
    boolean[][] maskArray;
    int dimX,dimY,dimT;
    String folderOut;
     
    Vector<Domain> domains; //here we store the identified domains.
    
    DPairHomogeneityComparator dpairComp = new DPairHomogeneityComparator();//Comparator class to sort domains pairs in decreasing order of their homogeneity
    DomainHomogeneityComparator domainComp = new DomainHomogeneityComparator();
    GridCellScoreComp gridCellComp = new GridCellScoreComp();
    PublicFunctions pf;
    CorrelationFunctions cf;
    
    public DomainIdentification(DeltaMAPSclm parent, Vector<GridCell> seeds)            
    {        
        this.dimT = parent.dimT;
        this.dimX = parent.dimX;
        this.dimY = parent.dimY;
        this.dataArray = parent.dataArray;
        this.maskArray = parent.maskArray;
        this.delta = parent.delta;
        this.folderOut = parent.folderOut;
        cf = new CorrelationFunctions(dimT);
        pf = new PublicFunctions();
        System.out.println("Domain identification started.");
        //step 0. To speed up things (when we calculate the correlations) at this point
        //we can go and normalize the data to zero mean and unit variance.        
        normalizeZeroMeanUnitVar();                                
        //step 1. Initialize the areas.
        System.out.println("Initializing domains.");
        initDomains(seeds);
        //step 2. iteratively merge and expand domains until no further merging or expansion is possible.                                        
        while(true)
        {
            System.out.println("Merging starts, current domains: "+domains.size());
            boolean merged = mergeDomains();            
            System.out.println("Merging ends, current domains: "+domains.size());
            System.out.println("Expansion starts");
            boolean expanded = expandDomains();            
            if(!merged && !expanded)
                break;
        } 
        //set the domain centroids 
        setDomainCentroids();
        //export some maps.
        printBorderMap(domains, "");
        printOverlapMap(domains, "");
        exportDMNfile(domains);
        System.out.println("Done.");
        System.out.println("Domains identified: "+domains.size());          
    }
    
    /*
    Domain merging is an iterative process. Two domains can be merged if (a) they are spatially adjacent
    and (b) if the homogeneity of their union satisfies the delta threshold. This function merges as many domains as possible
    and terminates if no merging is possible. If more than two domains can be merged we merge
    the one whose union results in greater homogeneity.
    RETURNS: merged = true if a at least one pair of domains have been merged, merged = false if no domains have been merged    
    */
    private boolean mergeDomains()
    {
        boolean merged = false;//merged -> true if at least one domain has been merged.
        while(true)
        {
            //Step 1. Find all pairs of domains that can be merged. 
            Vector<DomainPair> domainPairs = new Vector<DomainPair>();//Vector that will hold all pairs of domains that can be merged.
            //search between all pairs of domains
            int nDomains = domains.size();
            for(int i = 0; i < nDomains; i++)
            {
                Domain d1 = domains.get(i);
                for(int j = (i+1); j < nDomains; j++)
                {
                    Domain d2 = domains.get(j);
                    //check if the two domains overlap (or are spatially adjacent)
                    if(overlap(d1, d2))
                    {
                        //then create a new domain pair (candidate for merging)
                        DomainPair dpair = new DomainPair(d1,d2);
                        domainPairs.add(dpair);
                    }
                }
            }            
            //check if you have found at least one pair of domains, else terminate
            if(domainPairs.size() == 0)
                break;//terminate
            
            //Step 2. Merge the domains with the maximal homogeneity if the homogeneity if their union is larger than delta
            //first compute the homogeneity of theur union
            for(int i = 0; i < domainPairs.size(); i++)
                domainPairs.get(i).homogeneity = getHomogeneityUnion(domainPairs.get(i));
            //sort the domain pairs in decreasing homogeneity
            java.util.Collections.sort(domainPairs,this.dpairComp);
            //merge the two domains (with the maximal union homogeneity)  if their homogeneity is larger than delta
            DomainPair bestCandidate = domainPairs.firstElement();//this is the domain to be merged.
    
            if(bestCandidate.homogeneity > this.delta)
            {
                Domain mergedDomain = new Domain(bestCandidate.d1.id);
                mergedDomain.initGridCells();
                mergedDomain.gridCells.addAll(bestCandidate.d1.gridCells);
                mergedDomain.gridCells.addAll(bestCandidate.d2.gridCells);
                mergedDomain.homogeneity = bestCandidate.homogeneity;
                //now remove the two domains that have been merged
                domains.remove(domains.indexOf(bestCandidate.d1));
                domains.remove(domains.indexOf(bestCandidate.d2));                
                //and add the new domain
                domains.add(mergedDomain);
                merged = true;
            }
            else
            //if the candidate pairs with the maximal union homogeneity can not be merged then no other domain can be merged.
                break;                        
        }
        return merged;
    }
    
    /*
    Returns the homogeneity of the union of the two domains in the DomainPair dpair.
    */
    private double getHomogeneityUnion(DomainPair dpair)
    {        
        double homogeneity = 0;
        double denominator = 0;
        HashSet<Integer> unionHash = new HashSet<Integer>();
        unionHash.addAll(dpair.d1.gridCells);
        unionHash.addAll(dpair.d2.gridCells);       
        Object[] union = unionHash.toArray();//throw everything in an array so you can iterate between all pairs
     
        for(int i = 0; i < union.length; i++)//iterate between all pairs and compute their cross-correlation
        {            
            int pos1[] = pf.getPosition((Integer)union[i], dimX, dimY);
            double[] ts1 = dataArray[pos1[0]][pos1[1]];
            for(int j = (i+1); j < union.length; j++)
            {
                int pos2[] = pf.getPosition((Integer)union[j], dimX, dimY);
                double[] ts2 = dataArray[pos2[0]][pos2[1]];
                homogeneity+=cf.pearsonCorrelNorm(ts1, ts2);
                denominator++;
            }
        }                        
        return homogeneity/denominator;//return the average correlation
    }
    
    /*
    Returns true IF domains d1 and d2 are overlapping or spatially adjacent.
    */
    private boolean overlap(Domain d1, Domain d2)
    {
        boolean overlap = false;
        //Construct a HashSet holding the grid cells of d1, for each border grid cell
        //also include its neighbors.
        HashSet<Integer> set = new HashSet<Integer>();
        Iterator<Integer> it = d1.gridCells.iterator();
        while(it.hasNext())
        {
            Integer cellid = it.next();
            set.add(cellid);
            //and now add the spatial neighbors.
            set.addAll(pf.getNeighborsCross(cellid, dimX, dimY));
        }
        //now search for an overlap
        it = d2.gridCells.iterator();
        while(it.hasNext())
        {
            if(set.contains(it.next()))
            {
                overlap = true;
                break;
            }
        }
        return overlap;
    }
    
    /*
    Domain expansion starts by sorting the domains in decreasing order of homogeneity and starts
    expanding each domain (the expansion of a single domain is a separate function) in that order.
    After each expansion we check if merging is possible. 
    RETURN: expanded: true if at least on domain has been expanded.
    
    */
    private boolean expandDomains()
    {
        boolean expanded = false;
        boolean startMerging = false;//set to true if it is time to exit domain expansion and start merging again.        
        while(!startMerging)//while no merging is possible.
        {   //expand the domains in decreasing order of homogeneity.
            expanded = false;//set to false, cause (initialy) in this iteration no domain has been expanded
            //first, compute the homogeneity of each domain.    
            for(int i = 0; i < domains.size(); i++)            
                domains.get(i).homogeneity = getHomogeneity((Object[])domains.get(i).gridCells.toArray());

            
            //sort the areas by score in sescending order.
            java.util.Collections.sort(domains,domainComp);
            
            
            //try to expand areas, starting from the area with the highest homogeneity                
            Domain expandedDomain = null;
            for(int i = 0; i < domains.size(); i++)
            {
                Domain domain = domains.get(i);
                //try to expand the domain.
                expandedDomain = expandDomain(domain);
                if(expandedDomain.gridCells.size() > domain.gridCells.size() ) //then the domain has been expanded
                {                                        
                    expanded = true;//set expanded to true                    
                    domains.remove(i);
                    domains.add(i, expandedDomain);                    
                    //since the domain has been expanded we need to check if we can start merging.
                    //so, search for adjacent or overlapping domains.
                    for(int j = 0; j < domains.size(); j++)
                    {
                        if(i!=j)//do not check if you overlap with your self.
                        {
                            Domain domainToCheck = domains.get(j);
                            if(overlap(expandedDomain,domainToCheck))
                            {//if the two domains overlap or are spatialy adjacent
                                //check if their union homogeneity is > delta
                                DomainPair dpair = new DomainPair(expandedDomain, domainToCheck);
                                if(getHomogeneityUnion(dpair) > delta)//yes they can be merged, need to stop and start merging
                                {
                                    startMerging = true;
                                    break;
                                }
                            }
                        }
                    }
                    
                }          
                if(startMerging)//if you can merge the two domains exit and start merging.
                    break;
            }
            if(!expanded)//if no domain has been expanded, stop.
                break;
        }
        return expanded;
    }
    
    /*
    Function that expands a single domain by adding the grid cell that maximizes the average
    cross correlation to the grid cells already in the domain. A grid cell is added if and 
    only if it does not violate the homogeneity threshold.
    Input: Domain domain: The domain to be expanded.
    Output: Domain: The expanded domain. If the input can not be expanded it returns a domain with the
    same size as the input. 
    */
    private Domain expandDomain(Domain domain)
    {
        //initialize a set that will hold all grid cells in this domain
        HashSet<Integer> inDomain = new HashSet<Integer>(); 
        //and add all that are in already
        inDomain.addAll(domain.gridCells);
        //initialize the new domain.
        Domain expandedDomain = new Domain(domain.id);
        expandedDomain.initGridCells();                        
        //add the ones that are inside already
        expandedDomain.gridCells.addAll(domain.gridCells);
        expandedDomain.homogeneity = domain.homogeneity;
        //find the spatially adjacent grid cells.
        Vector<GridCell> neighboringCells = new Vector<GridCell>(); 
        Iterator<Integer> it = expandedDomain.gridCells.iterator();
        while(it.hasNext())
        {
            //get a grid cell in the domain
            int cellID = it.next();
            //get its four (up,down,left,right) adjacent neighbors.
            Vector<Integer> tempNeighs = pf.getNeighborsCross(cellID, dimX, dimY);
            //for each adjacent grid cell...
            for(int i = 0; i < tempNeighs.size(); i++)
            {
                int neighID = tempNeighs.get(i);
                int pos[] = pf.getPosition(neighID, dimX, dimY);
                //if the grid cell is not masked and not already in the domain...
                if(maskArray[pos[0]][pos[1]] == false && !inDomain.contains(neighID))
                {
                    GridCell n = new GridCell(neighID);
                    if(!neighboringCells.contains(n))//check so you won't add the same thing twice...
                        neighboringCells.add(n);
                }
            }
        }                
        //ready to start expanding the domain.
        //Stop criterion I:  the homogeneity of the best candidate grid cell (i.e. the one with the maximal homogeneity)
        //                   is less or equal than delta
        //Stop criterion II: when we do not have any neighboring cells left        
        if(neighboringCells.size() > 0) //Stop criterion II check here.
        {
            //calculate the score of all the grid cells.
            for(int i = 0; i < neighboringCells.size(); i++)                            
                    neighboringCells.get(i).score = getScore(neighboringCells.get(i).id,expandedDomain);            
            //sort the nodes by score
            java.util.Collections.sort(neighboringCells,gridCellComp);
            //and get the grid cell with the highest score
            GridCell bestCandidate = neighboringCells.remove(0);
                                    
            if(bestCandidate.score > delta)//Stop criterion I check here
            {
                //if the grid cell's score is larger than delta we can add it to the domain.
                //so, first thing is to compute the new domain's homogeneity
                double domainPairs = expandedDomain.gridCells.size()*(expandedDomain.gridCells.size()-1)/2;
                double currentAreaScore = domainPairs*expandedDomain.homogeneity;
                double bcScore = bestCandidate.score*expandedDomain.gridCells.size();
                expandedDomain.homogeneity = (bcScore+currentAreaScore)/ (double)(expandedDomain.gridCells.size()*(expandedDomain.gridCells.size()+1)/2);                
                //add the grid cell to the domain.
                expandedDomain.gridCells.add(bestCandidate.id);                                                    
            }            
        }
        return expandedDomain;//return the domain
    }
    
    /*
    Computes the score of a grid cell. The score of a grid cell is equal to the
    average pearson correlation between the grid cell and the grid cells in the domain.
    Input: 
    int from: the id of the grid cell that we want to compute its score
    Domain domainTo: the domain for which we want to compute the grid cell's score.
    */
    private double getScore(int from ,Domain domainTo)
    {
        double score = 0;
        double denominator = 0;
        int[] posFrom = pf.getPosition(from, dimX, dimY);        
        double[] tsFrom = dataArray[posFrom[0]][posFrom[1]];
        Iterator<Integer> it = domainTo.gridCells.iterator();
        while(it.hasNext())
        {
            int posTo[] = pf.getPosition(it.next(), dimX, dimY);
            double[] tsTo = dataArray[posTo[0]][posTo[1]];
            score += cf.pearsonCorrelNorm(tsFrom, tsTo);
            denominator++;
        }        
        return (score/denominator);
    }
    
    /*
    Function that returns the homogeneity of the grid cells in a domain.
    Homogeneity = average pairwise correlation between grid cells in a domain.
    */
    private double getHomogeneity(Object[] domainCells)
    {
        double homogeneity = 0.0;
        double denominator = 0;
        if(domainCells.length == 1)
            return 0.0;
        else
        {
            for(int i = 0; i < domainCells.length; i++)
            {
                int pos1[] = pf.getPosition((Integer)domainCells[i], dimX, dimY);
                double[] ts1 = dataArray[pos1[0]][pos1[1]];
                for(int j = (i+1); j < domainCells.length; j++)
                {
                    int pos2[] = pf.getPosition((Integer)domainCells[j], dimX, dimY);
                    double[] ts2 = dataArray[pos2[0]][pos2[1]];
                    homogeneity+=cf.pearsonCorrelNorm(ts1, ts2);
                    denominator++;
                }
            }
            homogeneity = homogeneity/denominator;            
            return homogeneity;
        }
    }

    
    /*
    INPUT: The seed grid cells identified from PeakIdentification.
    This function gets as an input the seed grid cells and for each
    seed it contructs a domain that contains the seed grid cell and
    its local neighborhood.
    */
    private void initDomains(Vector<GridCell> seeds)
    {
        domains = new Vector<Domain>();
        for(int i = 0; i < seeds.size(); i++)
        {
            Domain domain = new Domain(i);
            domain.initGridCells();
            domain.gridCells.add(seeds.get(i).id);
            domain.gridCells.addAll(seeds.get(i).localNeigh);
            domains.add(domain);
        }
    }
    
    /*
    Funrion to normalize the data to zero mean and unit variance.
    */
    private void normalizeZeroMeanUnitVar()
    {
        for(int i = 0; i < dimX; i++)
        {
            for(int j = 0; j < dimY; j++)
            {
                if(!maskArray[i][j])
                {
                    double[] ts = dataArray[i][j];
                    double newTs[] = new double[ts.length];
                    newTs = cf.normalizeToZeroMeanUnitVar(ts);
                    dataArray[i][j]=newTs;
                }
            }
        }
    }
    
    private void setDomainCentroids()
    {
        for(int i = 0; i < domains.size(); i++)
        {
            Domain d = domains.get(i);
            int[] centroid = getCentroid(d);
            domains.get(i).centroid = centroid;
        }
    }
    
    private int[] getCentroid(Domain domain)
    {
        int centroid[] = new int[2];
        double minDistance = Double.MAX_VALUE;
        int bestX = -1, bestY = -1;
        Iterator<Integer> from = domain.gridCells.iterator();
        while(from.hasNext())
        {
            //get the coordinates of a grid cell.
            int posFrom[] = pf.getPosition(from.next(), dimX, dimY);
            //calculate the distance to all other grid cells.
            Iterator<Integer> to = domain.gridCells.iterator();
            double distance = 0;
            while(to.hasNext())
            {
                int posTo[] = pf.getPosition(to.next(), dimX, dimY);
                distance+= pf.euclideanDistance(posFrom[0], posFrom[1], posTo[0], posTo[1]);
            }
            if(distance < minDistance)
            {
                minDistance = distance;
                bestX = posFrom[0];
                bestY = posFrom[1];
            }
        }
        centroid[0] = bestX; centroid[1] = bestY;
        return centroid;
    }
    
    
    
    /*
    Export functions go here.
    */
    /*
    Function that exports a .dmn file holding information about domains. 
    The output file can be used as an input to delta maps if one wants to perform
    network inference only.
    Output looks like
    Domain1_id domain1_centroidX domain1_centroidY color 
    id1 ud2 id3 id4 .... idN
    .
    .
    .
    DomainM_id domainM_centroidX domainM_centroidY
    id1 ud2 id3 id4 .... idN
    
    Thus, the output file exports domain information in consecutive 2-lines.
    The first line holds the domain id (unique identifier), the domain centroid x,y coordinates and the domain color (a unique double that enables us to paint adjacent domains with different colors).
    The second line holds the id of each grid cell in the domain's scope.
    
    In this example we have M domains and each domain has N grid cells. All entries are
    separated by a single space " " character. 
    
    */
    private void exportDMNfile(Vector<Domain> domains)
    {
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(this.folderOut+"domains.dmn"));
            for(int i = 0; i < domains.size(); i++)
            {
                Domain domain = domains.get(i);
                out.println(domain.id+" "+domain.centroid[0]+" "+domain.centroid[1]+" "+domain.color);
                Iterator<Integer> it = domain.gridCells.iterator();
                while(it.hasNext())                
                    out.print(it.next()+" ");
                out.print("\r\n");
            }
            out.close();
        }
        catch(IOException ioe)
        {}
    }
    
    private void printOverlapMap(Vector<Domain> domains, String delimeter)
    {
        int[][] map = new int[dimX][dimY];
        for(int i = 0; i < domains.size(); i++)
        {
            Domain domain = domains.get(i);
            Iterator<Integer> it = domain.gridCells.iterator();
            while(it.hasNext())            
            {
                int pos[] = pf.getPosition(it.next(), dimX, dimY);
                map[pos[0]][pos[1]]+=1;
            }
        }        
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folderOut+"overlapMap_"+delimeter+".txt"));
            for(int i = 0; i < dimX; i++)
            {
                for(int j = 0; j < dimY; j++)
                    out.print(map[i][j]+" ");
                out.println();
            }
            out.close();
        }
        catch(IOException ioe)
        {}
    }

    
    private void printBorderMap(Vector<Domain> domains, String delimeter)
    {
        int map[][] = new int[dimX][dimY];
        int borderID = (int)Math.floor(Math.random()*domains.size()+1);
        for(int i = 0; i < domains.size(); i++)
        {
            Domain domain = domains.get(i);
            Iterator<Integer> it = domain.gridCells.iterator();
            while(it.hasNext())                        
            {
                int cid = it.next();
                Vector<Integer> neighPos = pf.getNeighborsCross(cid, dimX, dimY);
                int isBorder = 0; //yes if <4.
                for(int z = 0; z < neighPos.size(); z++)
                {
                    if(domain.gridCells.contains(neighPos.get(z)))
                        isBorder++;
                }
                if(isBorder!=4)
                {
                    int pos[] = pf.getPosition(cid, dimX, dimY);
                    map[pos[0]][pos[1]]=borderID;
                }
            }
            borderID = (int)Math.floor(Math.random()*domains.size())+1;            
        }        
        //also set thee area centroids.
        for(int i = 0; i < domains.size(); i++)
        {
            Domain domain = domains.get(i);
            map[domain.centroid[0]][domain.centroid[1]]=1;
        }
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folderOut+"borderMap"+delimeter+".txt"));
            for(int i = 0; i < dimX; i++)
            {
                for(int j = 0; j < dimY; j++)
                    out.print(map[i][j]+" ");
                out.println();
            }
            out.close();
        }
        catch(IOException ioe)
        {}
    }

    
    
    
    
    
    
    
    
    //this is for later.....
    /*
    
    private boolean intersection(HashSet<Integer> setA, HashSet<Integer> setB)
    {
        boolean setAIsLarger = setA.size() > setB.size();
        HashSet<Integer> cloneSet = new HashSet<Integer>(setAIsLarger ? setB : setA);
        cloneSet.retainAll(setAIsLarger ? setA : setB);
        return !cloneSet.isEmpty();
    }
    
    /*
    returns true if setA and setB intersect.
    */
    /*
    private boolean intersection2(HashSet<Integer> setA, HashSet<Integer> setB)
    {        
        if(setA.size() > setB.size())
        {
            boolean intersect = false;
            java.util.Iterator<Integer> it = setB.iterator();
            while(it.hasNext())
            {
                if(setA.contains(it.next()))
                {
                    intersect=true;                   
                }
            }
            return intersect;
        }
        else
        {
            boolean intersect = false;
            java.util.Iterator<Integer> it = setA.iterator();
            while(it.hasNext())
            {
                if(setB.contains(it.next()))
                {
                    intersect=true;                   
                }
            }
            return intersect;
        }
    }
    
    private boolean expandDomains()
    {
        return false;
    }
    */
    
    
}


/*
Class that holds two domains that can be memrged.
*/
class DomainPair
{    
    Domain d1;//the two domains.
    Domain d2;
    double homogeneity;//homogeneity of the union of d1,d2
    
    public DomainPair(Domain d1, Domain d2)
    {
        this.d1 = new Domain(d1.id);
        this.d1.initGridCells();
        this.d1.gridCells.addAll(d1.gridCells);
        
        this.d2 = new Domain(d2.id);
        this.d2.initGridCells();
        this.d2.gridCells.addAll(d2.gridCells);
    }
    

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + this.d1.id;
        hash = 29 * hash + this.d2.id;
        return hash;
    }
    
    public boolean equals(Object o)
    {
        if(this.getClass()!=o.getClass())
            return false;
        DomainPair dpair = (DomainPair)o;
        if(this.d1.id == dpair.d1.id && this.d2.id == dpair.d2.id)
            return true;
        else return false;
    }
}

//sorts the domain pairs in decreasing order of their union homogeneity.
class DPairHomogeneityComparator implements Comparator<DomainPair>
{
    @Override
    public int compare(DomainPair d1, DomainPair d2)
    {
        if(d1.homogeneity < d2.homogeneity)
            return 1;
        else if(d1.homogeneity > d2.homogeneity)
            return -1;
        else return 0;
                                                
    }
}


//sorts the domain pairs in decreasing order of their union homogeneity.
class DomainHomogeneityComparator implements Comparator<Domain>
{
    @Override
    public int compare(Domain d1, Domain d2)
    {
        if(d1.homogeneity < d2.homogeneity)
            return 1;
        else if(d1.homogeneity > d2.homogeneity)
            return -1;
        else return 0;
                                                
    }
}

//sorts the grid cells in decreasing order of their score.
class GridCellScoreComp implements Comparator<GridCell>
{
    @Override
    public int compare(GridCell n1, GridCell n2)
    {
        if(n1.score < n2.score)
            return 1;
        else if(n1.score > n2.score)
            return -1;
        else return 0;
                                                
    }
}
