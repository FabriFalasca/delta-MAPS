

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Vector;

/**
 *
 * @author ilias
 */
public class Domain {
    
    int id; //unique area id.
    HashSet<Integer> gridCells; //holds the unique ids of the grid cells in a domain.
    double homogeneity; //the homogeneity of a domain (equal to the average pair-wise correlation between grid cell in the domain's scope)
    int[] centroid;//array holding the [x,y] coordinates in the grid that hold the most central point of the domain. The most central point is the one that minimizes the distance to all other points in the domain.
    double size;
    double[] domainCA; //array holding a domain's cummulative anomaly time series.
    Vector<DomainEdge> edges = new Vector<DomainEdge>();
    double strength;
    
    ArrayList<Edge> mapColEdges = new ArrayList<>();//just for map coloring
    double color;
    
    public Domain(int id)
    {this.id = id;}
    
    public void initGridCells()
    {
        gridCells = new HashSet<Integer>();
    }
    
    public void initDomainCA(double[] ts)
    {
        this.domainCA = new double[ts.length];
        for(int t = 0; t < ts.length; t++)
            domainCA[t] = ts[t];
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(this.getClass()!=o.getClass())
            return false;
        Domain d = (Domain)o;
        return this.id == d.id;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + this.id;
        return hash;
    }
    
}


//Edge class for MAP COLORING ONLY
class Edge
{
    //edge id's are adjacency matrix id's
    int from, to;

    
    public Edge(int from, int to)
    {
        this.from = from;
        this.to = to;        
    }
    

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 67 * hash + this.from;
        hash = 67 * hash + this.to;
        return hash;
    }
    
    @Override
    public boolean equals(Object o)
    {
        Edge e = (Edge)o;
        if(!(e instanceof Edge))
            return false;
        else if(e.from == this.from && e.to == this.to)
            return true;
        else if(e.from == this.to && e.to == this.from)
            return true;//graph is undirected...
        else return false;
    }
    
}
