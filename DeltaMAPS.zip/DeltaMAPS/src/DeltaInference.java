
/**
 *
 * @author Foudalis
 */
public class DeltaInference {
    
    //The heuristic to infer delta requires to select a random sample
    //of pairs of grid cells.
    int sampleSize = 1000000; //This variable shows the sample size.
    double delta;//the delta threshold
    int dimX,dimY,dimT;
    
    public DeltaInference(double[][][] dataMatrix, boolean[][] maskArray, double domainSigLevel)    
    {
        
        System.out.println("Delta inference starts.");
        System.out.println("Significance level set to: "+domainSigLevel);
        this.dimT = dataMatrix[0][0].length;
        this.dimY = dataMatrix[0].length;
        this.dimX = dataMatrix.length;
        CorrelationFunctions cf = new CorrelationFunctions(dimT);
        double sumSigCorr = 0.0;//will hold the sum of all significant correltions.
        double nSigCorr = 0.0;//will hold the number of significant correlations
        double minSigCorr = 1.0;// the minimum correlation which you found as significant for the given domain significance level.
        int currentSamples = 0;
        while(currentSamples != sampleSize)//repear loop until you have all the samples that you need.
        {
            //select at random two pairs of grid cells.
            int posX1 = (int)Math.floor(Math.random()*dimX);
            int posY1 = (int)Math.floor(Math.random()*dimY);
            int posX2 = (int)Math.floor(Math.random()*dimX);
            int posY2 = (int)Math.floor(Math.random()*dimY);
            //check if the two grid cells are not masked
            if(!maskArray[posX1][posY1] && !maskArray[posX2][posY2])
            {
                //get the time series of the two grid cells.
                double ts1[] = dataMatrix[posX1][posY1];
                double ts2[] = dataMatrix[posX2][posY2];
                //compute their pearson correlation at zero lag
                double corr = cf.pearsonCorrel(ts1, ts2);
                //do a significance test
                double bVar = cf.varianceBartlett(ts1, ts2);
                double zij = corr/Math.sqrt(bVar);//this will approximately follow a normal distribution
                double pval = 1-DistLib.normal.cumulative(zij, 0.0, 1.0);                
                if(pval < domainSigLevel)//then correlation is significant
                {
                    sumSigCorr+=corr;
                    nSigCorr++;
                    if(minSigCorr > corr )
                        minSigCorr=corr;
                }
                currentSamples++;
            }
        }
        System.out.println("Minimum significant correlation: "+minSigCorr);
        this.delta = sumSigCorr/nSigCorr;
    }
    
    //return the delta threshold.
    public double getDelta()
    {
        return delta;
    }
    
}
