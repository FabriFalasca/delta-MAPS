

import java.util.Vector;


/**
 *
 * @author Foudalis
 */
public class GridCell {
    
    int id;
    Vector<Integer> localNeigh;//int array holding the id's of the K nearest neighbors
    double localHomog; //local homogeneity
    double distance;//distance from another grid cell
    boolean canBeSeed = true;//set to false if you can not get all K nearest neighbors.       
    double score;
    
    
    public GridCell(int id)
    {
        this.id = id;
    }
    
    public void initNeighbors(int neighSizeK)
    {
        localNeigh = new Vector<Integer>();
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(this.getClass()!=o.getClass())
            return false;
        GridCell c = (GridCell)o;
        return this.id ==  c.id;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + this.id;
        return hash;
    }
    
    
}
