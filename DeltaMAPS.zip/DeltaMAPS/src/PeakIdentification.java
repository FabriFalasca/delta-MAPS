

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.Vector;

/**
 *
 * @author Foudalis
 */
public class PeakIdentification {
    
    double delta;
    int neighSizeK, dimX,dimY,dimT;
    boolean[][] maskArray;
    double[][][] dataArray;
    String folderOut;
    
    Vector<GridCell> gridCells;
    Vector<GridCell> seeds;
    double[][] localHomogField;
    PublicFunctions pf = new PublicFunctions();
    CorrelationFunctions cf;
    
    PointDistanceComparator pDistComp = new PointDistanceComparator();
    
    
    public PeakIdentification(DeltaMAPSclm parent)
    {
        this.delta = parent.delta;
        this.dimX = parent.dimX;
        this.dimY = parent.dimY;
        this.dimT = parent.dimT;
        this.neighSizeK = parent.neighSizeK;
        this.maskArray = parent.maskArray;
        this.dataArray = parent.dataArray;        
        this.folderOut = parent.folderOut;
        cf = new CorrelationFunctions(dimT);
        //step 1. construct local neighborhoods
        System.out.println("Constructing k-local neighborhood");
        constructLocalNeighborhoods();        
        //step 2. compute correlation field
        System.out.println("Computing local correlation field");
        constructLocalHomogeneityField();
        //print the local homogeneity field
        printMap(localHomogField, "localHomogeneityField");
        //step 3. infer local maxima (seeds)
        System.out.println("Seed inference started.");
        seedIdentification();       
        System.out.println("Done.");      
    }
    
    /*
    Function for seed inference. A grid cell is a seed if its local homogeneity
    is larger or equal than the local homogeneity of the grid cells in its local
    neighborhood and if the local homogeneity of the grid cell is larger than delta.
    A seed includes the seed grid cell and the grid cells in its local neighborhood.
    */
    private void seedIdentification()
    {
        //initialize the vector that will hold the seed grid cells.
        seeds = new Vector<GridCell>();
        //2D array holding the location of the identified seeds.
        //false - grid cell is not a seed. true - grid cell is a seed.
        boolean[][] seedMap = new boolean[dimX][dimY];
        int nGridCells = gridCells.size();
        for(int i = 0; i < nGridCells; i++)
        {   //for each grid cell.
            GridCell gc = gridCells.get(i);
            //get the grid cell's position
            int myPos[] = pf.getPosition(gc.id,dimX,dimY);
            //get the local homogeneity of the grid cell
            double myScore = localHomogField[myPos[0]][myPos[1]];
            if(myScore > delta)//criterion no 1. for a grid cell to be a seed its local homogeneity must be larger than delta.
            {                
                boolean peak = true;
                //scan through your k closest neighbors.
                for(int j = 0; j < (this.neighSizeK+1); j++)//plus 1 because you are included in your local neighborhod.
                {   
                    //get the [x,y] position of your neighbor
                    int[] neighPos = pf.getPosition(gc.localNeigh.get(j), dimX, dimY);
                    //compare your local homogeneity to your neighbor's
                    if(localHomogField[neighPos[0]][neighPos[1]] == 0)
                    {
                        //no data, all your neighbors must have a local homogeneity for you to be a seed.
                        peak = false;
                        break;
                    }
                    if(myScore < localHomogField[neighPos[0]][neighPos[1]] )
                    {
                        //not a local maximum.
                        peak = false;
                        break;
                    }
                } 
                //mark seed/no seed.
                seedMap[myPos[0]][myPos[1]]=peak;
                //if you are a seed...
                if(peak)//add your self
                    seeds.add(gridCells.get(i));
            }
                                    
        }
        
        //done, prepare and print a map;
        //the map is a 2D array holding the local homogeneity scores
        //as well as the location of seed grid cells (marked with a -2)
        double[][] mapOut = localHomogField;
        for(int i = 0; i < dimX; i++)
        {
            for(int j = 0; j < dimY; j++)
                if(seedMap[i][j])
                    mapOut[i][j]=-2;
        }
        printMap(mapOut, "seedMap");
        
        System.out.println("Found "+seeds.size()+" seeds");
    }

    
    /*
    Constructs a 2D matrix, each non-zero entry in the matrix holds the local
    homogeneity of the corresponding grid cell.
    */
    private void constructLocalHomogeneityField()
    {
        //init. local homogeneity matrix
        localHomogField = new double[dimX][dimY];
        for(int i = 0; i < gridCells.size(); i++)
        {
            GridCell gc = gridCells.get(i);
            //get the local homogeneity of grid cell gc.
            double lh = getLH(gc);
            gridCells.get(i).localHomog = lh;
            int[] pos = pf.getPosition(gc.id, dimX, dimY);
            localHomogField[pos[0]][pos[1]] = lh;
        }
    }
    
    /*
    Returns the average pair-wise correlation of the grid cells
    in the local neighborhood of gc (i.e., returns the local
    homogeneity of gc\
    */
    private double getLH(GridCell gc)
    {
        int nElements = gc.localNeigh.size();
        double lh = 0.0;
        double denom = 0.0;       
        for(int i = 0; i < nElements; i++)
        {
            int posA[] = pf.getPosition(gc.localNeigh.get(i), dimX, dimY);
            for(int j = (i+1); j < nElements; j++)
            {
                int posB[] = pf.getPosition(gc.localNeigh.get(j), dimX, dimY);
                lh+= cf.pearsonCorrel(dataArray[posA[0]][posA[1]], dataArray[posB[0]][posB[1]]);
                denom++;
            }
        }
        
        return (lh/denom);
    }


    /*
    Function to construct \Gamma_k(i): The local neighborhood of grid cell i.
    The local neighborhood of a grid cell i includes i and its k nearest grid cells.
    */
    private void constructLocalNeighborhoods()
    {        
        //initialize the vector that holds the grid cells.
        gridCells = new Vector<GridCell>();
        //add grid cells to the vector (the vector will hold non-masked grid cells only). 
        for(int x = 0; x < dimX; x++)
        {
            for(int y = 0; y < dimY; y++)
            {
                //first check if grid cell is not masked
                if(!maskArray[x][y])
                {
                    int gridCellID = pf.arrayToId(x, y, dimY);
                    GridCell gc = new GridCell(gridCellID);
                    gc.initNeighbors(neighSizeK);
                    gc.localNeigh.addAll(getLocalNeighborhoodDistance(gridCellID));
                    gridCells.add(gc);
                }
            }
        }
        //clean up phase
        //remove all grid cells for which we could not find K non-masked neighbors.
        Vector<GridCell> toRemove = new Vector<GridCell>();
        for(int i = 0; i < gridCells.size(); i++)
        {
            if(gridCells.get(i).localNeigh.size()!=this.neighSizeK+1)//+1 because it contains it self 
                toRemove.add(gridCells.get(i));
        }
        gridCells.removeAll(toRemove);        
    }

    /*
    Function that returns a Vector with the id's of the k-closest grid cells
    INPUT: the id of a grid cell for which we want its k closest points.    
    */
    private Vector<Integer> getLocalNeighborhoodDistance(int gridCellID)
    {
        //initialize the Vector that will hold the local neighborhood
        Vector<Integer> neighborhood = new Vector<Integer>();
        //Step 1. add yourself to the neighborhood.
        neighborhood.add(gridCellID);
        //mark your start position/location
        int posStart[] = pf.getPosition(gridCellID, dimX, dimY);         
        //calculate the distance to all grid cells
        //this Vector will hold the distance to all grid cells excluding "yourself"
        Vector<Point> kClosestPoints = new Vector<Point>();
        for(int i = 0; i < dimX; i++)
        {
            for(int j = 0; j < dimY; j++)
            {
                //get the e id of the grid cell
                int id = pf.arrayToId(i, j, dimY);
                //if it is not yourself
                if(id!=gridCellID)
                {
                    double distance = euclidianDistance(posStart[0], posStart[1], i, j);
                    Point p = new Point(id);
                    p.distance = distance;
                    kClosestPoints.add(p);
                }
            }
        }        
        //sort by distance in ascending order
        java.util.Collections.sort(kClosestPoints,pDistComp);
        //add the K closest points               
        for(int i = 0; i < this.neighSizeK; i++)
        {
            int cellid = kClosestPoints.get(i).id;
            int pos[] = pf.getPosition(cellid, dimX, dimY);
            //if the kth closest point is masked do not add it
            if(!maskArray[pos[0]][pos[1]])
                neighborhood.add(cellid);
        }        
        return neighborhood;
    }
    
    //returns the Euclidean distance between (x1,y1) and (x2,y2)
    private double euclidianDistance(double x1, double y1, double x2, double y2)
    {return Math.sqrt(Math.pow(x1-x2, 2)+ Math.pow(y1-y2, 2));}

    
    /*
    Exports a 2D array in a file named "fname.txt". Succesive columns are separated
    by a single space and succesive rows by a new line.
    Input: map: 2D array of doubles, fname: name of file
    */
    private void printMap(double[][] map, String fname)
    {
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter(folderOut+fname+".txt"));
            for(int i = 0; i < map.length; i++)
            {
                for(int j = 0; j < map[i].length; j++)
                    out.print(map[i][j]+" ");
                out.println();
            }
            out.close();
        }
        catch(IOException ioe)
        {}
    }
    
   
    
}



class PointDistanceComparator implements Comparator<Point>
{
    @Override
    public int compare(Point n1, Point n2)
    {
        if(n1.distance > n2.distance)
            return 1;
        else if(n1.distance < n2.distance)
            return -1;
        else return 0;
                                                
    }
}


class Point
{
    int id;//same as the grid cell id
    double distance;//distance from another grid cell
    
    public Point(int id)
    {this.id = id;}

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + this.id;
        return hash;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(this.getClass()!=o.getClass())
            return false;
        Point p = (Point)o;
        return p.id == this.id;
    }
}
